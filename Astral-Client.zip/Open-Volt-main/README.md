https://discord.gg/qwKegVhc9H
<p align="center"><img src="logo.png" width="220" alt="Astral Client"></p>

# Astral Client

**Made by xafich1** — based on OpenVolt (credits to the original authors below).

Astral Client is a free, open-source re-skin of **OpenVolt** with a dark blue / purple galaxy theme and a smoother, cleaner click GUI.
All features and module behaviour are unchanged from OpenVolt.

Changes in this fork:
- New name, logo and mod icon (Astral Client)
- Galaxy colour palette (navy / violet / lavender) across the GUI and HUD
- Rounded, anti-aliased click GUI with twinkling stars, time-based animations and smooth scrolling
- Config folder is now `Astral/profiles` (copy your old `Volt/profiles` files over to keep your configs)

---

# OpenVolt (original README)

A 1.21.1 client (for 1.9 combat).

This client is still going to be worked on.

# Why?

The client was originally meant to be paid, but I decided to make it FOSS. Hopefully, the community can come together to make this client better than every other client available.

# People Who Helped Make Volt Happen

Lvstrng (1037070137041375412) – Client base

Walper (957343617272414230) – One of the best people I’ve met in this community

Koi (1227992566339731479) – The best person I could have met, helped a lot with Volt and knows 1.9 combat better than I do

Etho (1383737664645369926) – Moral support & Walmart Solutions

3000IQPlay (1193266310977691760) – Gave me help on what to do with Volt (also made Walmart Solutions, which made me try 1.21)

# How to Contribute? 
Either join the discord and DM me or make a pull request!
I won't accept pull requests which refactor a lot of packages or are utterly pointless.
(All Blatant features will get declined.)

# Commit rules

 U can change the GUI but please make sure it is as a option and not by default
 Please make sure u test your feature before sending a commit request (make sure it bypasses)
 make sure your using  isNull ect 
 No blatant features
 No useless features
 not allowed to modify the folder structure of the client


# Before pasting!

Don't sell this please or at least credit Koi, Walper and me before taking our code! Thanks.

....
