package com.volt.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.volt.utils.render.RenderUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

import java.awt.Color;
import java.util.Random;

/**
 * Astral Client colour palette + a few shared drawing helpers (starfield, logo, glow).
 * Dark blue / purple "galaxy" look, anchored on the lavender of the Astral moon logo.
 */
public final class Theme {
    private Theme() {}

    // Backgrounds (deep navy -> deep violet)
    public static final Color BG_TOP        = new Color(10, 12, 36);
    public static final Color BG_BOTTOM     = new Color(30, 17, 56);
    public static final Color HEADER        = new Color(18, 18, 52);
    public static final Color SIDEBAR       = new Color(9, 10, 30);
    public static final Color CONTENT       = new Color(12, 12, 36);
    public static final Color CARD          = new Color(26, 24, 68);
    public static final Color CARD_HOVER    = new Color(38, 34, 92);
    public static final Color SETTINGS_BG   = new Color(8, 9, 28);
    public static final Color FIELD         = new Color(30, 28, 76);
    public static final Color FIELD_HOVER   = new Color(44, 40, 104);
    public static final Color BORDER        = new Color(96, 78, 190);

    // Accents
    public static final Color ACCENT        = new Color(139, 99, 255);   // violet
    public static final Color ACCENT_LIGHT  = new Color(202, 170, 243);  // logo lavender
    public static final Color ACCENT_BLUE   = new Color(92, 124, 255);   // galaxy blue
    public static final Color ACCENT_DEEP   = new Color(88, 60, 200);

    // Text
    public static final Color TEXT          = new Color(240, 237, 255);
    public static final Color TEXT_DIM      = new Color(176, 170, 220);
    public static final Color TEXT_MUTED    = new Color(112, 106, 164);

    public static Color alpha(Color c, int a) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, a)));
    }

    /** Colour with its own alpha scaled by {@code mul}. */
    public static int rgb(Color c, float mul) {
        int a = Math.max(0, Math.min(255, (int) (c.getAlpha() * mul)));
        return (a << 24) | (c.getRGB() & 0x00FFFFFF);
    }

    public static Color mix(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        return new Color(
                (int) (a.getRed() + (b.getRed() - a.getRed()) * t),
                (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * t),
                (int) (a.getAlpha() + (b.getAlpha() - a.getAlpha()) * t));
    }

    /** Soft drop shadow made of a few expanding, very faint rounded rects. */
    public static void drawShadow(DrawContext ctx, int x, int y, int w, int h, int radius, float alpha) {
        for (int i = 10; i >= 1; i -= 2) {
            int a = (int) (9 * alpha);
            if (a <= 0) continue;
            RenderUtils.drawRoundedRect(ctx, x - i, y - i + 4, w + i * 2, h + i * 2, radius + i, (a << 24) | 0x05030F);
        }
    }

    // ---- starfield ---------------------------------------------------------------------------

    private static final int STAR_COUNT = 90;
    private static final float[] STAR_X = new float[STAR_COUNT];
    private static final float[] STAR_Y = new float[STAR_COUNT];
    private static final float[] STAR_PHASE = new float[STAR_COUNT];
    private static final float[] STAR_SPEED = new float[STAR_COUNT];
    private static final int[] STAR_SIZE = new int[STAR_COUNT];
    private static final int[] STAR_COLOR = new int[STAR_COUNT];

    static {
        Random rng = new Random(0xA57A1L);
        int[] palette = {0xFFFFFF, 0xCAAAF3, 0x9DB4FF, 0xB89BFF};
        for (int i = 0; i < STAR_COUNT; i++) {
            STAR_X[i] = rng.nextFloat();
            STAR_Y[i] = rng.nextFloat();
            STAR_PHASE[i] = rng.nextFloat() * 6.2831f;
            STAR_SPEED[i] = 0.6f + rng.nextFloat() * 1.6f;
            STAR_SIZE[i] = rng.nextInt(10) == 0 ? 2 : 1;
            STAR_COLOR[i] = palette[rng.nextInt(palette.length)];
        }
    }

    /** Twinkling stars, clipped to the given (inner) rectangle. */
    public static void drawStars(DrawContext ctx, int x, int y, int w, int h, float alpha) {
        if (alpha <= 0.01f) return;
        double t = System.currentTimeMillis() / 1000.0;
        for (int i = 0; i < STAR_COUNT; i++) {
            float twinkle = 0.5f + 0.5f * (float) Math.sin(t * STAR_SPEED[i] + STAR_PHASE[i]);
            float a = (0.28f + 0.62f * twinkle) * alpha;
            int sx = x + (int) (STAR_X[i] * (w - 2));
            int sy = y + (int) (STAR_Y[i] * (h - 2));
            int color = ((int) (a * 255) << 24) | STAR_COLOR[i];
            int size = STAR_SIZE[i];
            ctx.fill(sx, sy, sx + size, sy + size, color);
            if (size == 2 && twinkle > 0.6f) {
                int halo = ((int) (a * 70) << 24) | STAR_COLOR[i];
                ctx.fill(sx - 1, sy, sx, sy + size, halo);
                ctx.fill(sx + size, sy, sx + size + 1, sy + size, halo);
                ctx.fill(sx, sy - 1, sx + size, sy, halo);
                ctx.fill(sx, sy + size, sx + size, sy + size + 1, halo);
            }
        }
    }

    // ---- logo --------------------------------------------------------------------------------

    private static final Identifier LOGO = Identifier.of("astral-client", "logo_moon.png");
    private static boolean logoFilterSet = false;

    /** Draws the Astral moon (transparent PNG made from the supplied logo). */
    public static void drawLogo(DrawContext ctx, int x, int y, int size, float alpha) {
        if (!logoFilterSet) {
            logoFilterSet = true;
            try {
                MinecraftClient.getInstance().getTextureManager().getTexture(LOGO).setFilter(true, false);
            } catch (Throwable ignored) {
            }
        }
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1f, 1f, 1f, Math.max(0f, Math.min(1f, alpha)));
        ctx.drawTexture(LOGO, x, y, size, size, 0f, 0f, 64, 64, 64, 64);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
    }
}
