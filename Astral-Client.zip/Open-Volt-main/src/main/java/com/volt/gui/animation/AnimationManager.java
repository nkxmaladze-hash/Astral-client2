package com.volt.gui.animation;

import com.volt.module.Category;
import com.volt.module.Module;
import net.minecraft.util.math.MathHelper;

import java.util.HashMap;
import java.util.Map;

public class AnimationManager {
    private final Map<Category, Float> categoryAnimations = new HashMap<>();
    private final Map<Module, Float> moduleAnimations = new HashMap<>();
    private final Map<Module, Float> dropdownAnimations = new HashMap<>();
    private float sidebarAnimation = 0;
    private float contentAnimation = 0;
    

    private float guiAnimation = 0f;
    private float scaleAnimation = 0f;
    private boolean isClosing = false;
    private boolean animationComplete = false;
    private long openTime = 0;
    
    public AnimationManager() {
        for (Category category : Category.values()) {
            categoryAnimations.put(category, 0f);
        }
    }
    
    public void initializeModuleAnimations(Module module) {
        moduleAnimations.put(module, 0f);
        dropdownAnimations.put(module, 0f);
    }
    
    public void updateCategoryAnimation(Category category, boolean isSelected, boolean isHovered, float delta) {
        float targetAnimation = isSelected ? 1f : (isHovered ? 0.3f : 0f);
        float currentAnimation = categoryAnimations.get(category);
        float newAnimation = MathHelper.lerp(0.15f, currentAnimation, targetAnimation);
        categoryAnimations.put(category, newAnimation);
    }
    
    public void updateModuleAnimation(Module module, boolean isEnabled, boolean isHovered, float delta) {
        float targetAnimation = isEnabled ? 1f : (isHovered ? 0.2f : 0f);
        float currentAnimation = moduleAnimations.getOrDefault(module, 0f);
        float newAnimation = MathHelper.lerp(0.12f, currentAnimation, targetAnimation);
        moduleAnimations.put(module, newAnimation);
    }
    
    public void updateDropdownAnimation(Module module, boolean isExpanded, float delta) {
        float targetDropdown = isExpanded ? 1f : 0f;
        float currentDropdown = dropdownAnimations.getOrDefault(module, 0f);
        float newDropdown = MathHelper.lerp(0.15f, currentDropdown, targetDropdown);
        dropdownAnimations.put(module, newDropdown);
    }
    
    public void updateSidebarAnimation(float target, float delta) {
        sidebarAnimation = MathHelper.lerp(0.1f, sidebarAnimation, target);
    }
    
    public void updateContentAnimation(float target, float delta) {
        contentAnimation = MathHelper.lerp(0.1f, contentAnimation, target);
    }
    
    public float getCategoryAnimation(Category category) {
        return categoryAnimations.getOrDefault(category, 0f);
    }
    
    public float getModuleAnimation(Module module) {
        return moduleAnimations.getOrDefault(module, 0f);
    }
    
    public float getDropdownAnimation(Module module) {
        return dropdownAnimations.getOrDefault(module, 0f);
    }
    
    public float getSidebarAnimation() {
        return sidebarAnimation;
    }
    
    public float getContentAnimation() {
        return contentAnimation;
    }
    
    private long lastFrameNanos = 0L;
    private float dt = 1f / 60f;

    /** Advances the frame clock. Animations run on real elapsed time so they look the same at any FPS. */
    public void updateAnimations(float delta) {
        long now = System.nanoTime();
        if (lastFrameNanos != 0L) {
            dt = Math.max(0.001f, Math.min((now - lastFrameNanos) / 1_000_000_000f, 0.05f));
        }
        lastFrameNanos = now;
    }

    /** Seconds since the previous rendered frame (clamped). */
    public float getDt() {
        return dt;
    }

    /** Frame-rate independent exponential smoothing towards {@code target}. */
    public float smooth(float current, float target, float speed) {
        float next = current + (target - current) * (1.0f - (float) Math.exp(-speed * dt));
        return Math.abs(next - target) < 0.001f ? target : next;
    }
    
    public void setCategoryAnimation(Category category, float value) {
        categoryAnimations.put(category, value);
    }
    
    public void setModuleAnimation(Module module, float value) {
        moduleAnimations.put(module, value);
    }
    
    public void setDropdownAnimation(Module module, float value) {
        dropdownAnimations.put(module, value);
    }
    

    public void initializeGuiAnimation() {
        this.guiAnimation = 0f;
        this.scaleAnimation = 0f;
        this.isClosing = false;
        this.animationComplete = false;
        this.openTime = System.currentTimeMillis();
    }
    
    public void updateGuiAnimations() {
        updateGuiAnimations(1.0f / 60.0f);
    }
    
    public void updateGuiAnimations(float deltaTime) {
        long currentTime = System.currentTimeMillis();
        float timeSinceOpen = (currentTime - openTime) / 1000f;

        deltaTime = Math.max(0.001f, Math.min(deltaTime, 0.05f));

        if (isClosing) {
            float k = 1.0f - (float) Math.exp(-13.0f * deltaTime);
            guiAnimation = MathHelper.lerp(k, guiAnimation, 0f);
            scaleAnimation = MathHelper.lerp(k, scaleAnimation, 0.96f);

            if (guiAnimation <= 0.05f && !animationComplete) {
                animationComplete = true;
            }
        } else {
            float k = 1.0f - (float) Math.exp(-11.0f * deltaTime);
            guiAnimation = MathHelper.lerp(k, guiAnimation, 1f);

            // Gentle ease-out-cubic "settle" (no overshoot / wobble).
            float p = Math.min(timeSinceOpen / 0.30f, 1f);
            float eased = 1f - (float) Math.pow(1f - p, 3f);
            scaleAnimation = 0.94f + 0.06f * eased;
        }
    }

    public boolean shouldCloseGui() {
        return guiAnimation <= 0.05f && isClosing && animationComplete;
    }
    
    public void startClosingAnimation() {
        if (!isClosing) {
            isClosing = true;
            animationComplete = false;
        }
    }
    
    public float getGuiAnimation() {
        return guiAnimation;
    }
    
    public float getScaleAnimation() {
        return scaleAnimation;
    }
    
    public boolean isClosing() {
        return isClosing;
    }
    
    public boolean isAnimationComplete() {
        return animationComplete;
    }
}