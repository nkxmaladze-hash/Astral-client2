package com.volt.gui.components;


import com.volt.gui.Theme;
import com.volt.utils.render.RenderUtils;
import net.minecraft.client.gui.DrawContext;
import java.awt.Color;

public class UIRenderer {

    public static void renderRoundedRect(DrawContext context, int x, int y, int width, int height, int radius, Color color) {
        RenderUtils.drawRoundedRect(context, x, y, width, height, radius, color.getRGB());
    }

    public static void renderDropdownArrow(DrawContext context, int x, int y, boolean expanded, Color color) {
        int arrowSize = 8;
        int halfSize = arrowSize / 2;

        if (expanded) {
            context.fill(x - halfSize, y - 2, x + halfSize, y - 1, color.getRGB());
            context.fill(x - halfSize + 1, y - 1, x + halfSize - 1, y, color.getRGB());
            context.fill(x - halfSize + 2, y, x + halfSize - 2, y + 1, color.getRGB());
            context.fill(x - 1, y + 1, x + 1, y + 2, color.getRGB());
        } else {
            context.fill(x - 2, y - halfSize, x - 1, y + halfSize, color.getRGB());
            context.fill(x - 1, y - halfSize + 1, x, y + halfSize - 1, color.getRGB());
            context.fill(x, y - halfSize + 2, x + 1, y + halfSize - 2, color.getRGB());
            context.fill(x + 1, y - 1, x + 2, y + 1, color.getRGB());
        }
    }

    public static void renderSlider(DrawContext context, int x, int y, int width, int height, double normalized, Color trackColor, Color fillColor) {
        float clamped = (float) Math.max(0.0, Math.min(1.0, normalized));
        int radius = height / 2;

        RenderUtils.drawRoundedRect(context, x, y, width, height, radius, trackColor.getRGB());

        int fillWidth = (int) (width * clamped);
        if (fillWidth > 0) {
            RenderUtils.drawRoundedRect(context, x, y, Math.max(fillWidth, height), height, radius, fillColor.getRGB());
        }

        // Round knob that sits on the end of the fill.
        int knob = height + 4;
        int knobX = x + fillWidth - knob / 2;
        knobX = Math.max(x - 1, Math.min(x + width - knob + 1, knobX));
        int knobY = y + (height - knob) / 2;
        RenderUtils.drawRoundedRect(context, knobX - 1, knobY - 1, knob + 2, knob + 2, (knob + 2) / 2, Theme.alpha(Theme.BG_TOP, 150).getRGB());
        RenderUtils.drawRoundedRect(context, knobX, knobY, knob, knob, knob / 2, Theme.TEXT.getRGB());
    }

    public static void renderCheckbox(DrawContext context, int x, int y, int size, boolean enabled, Color borderColor, Color fillColor) {
        RenderUtils.drawRoundedRect(context, x, y, size, size, 4, borderColor.getRGB());
        RenderUtils.drawRoundedRect(context, x + 1, y + 1, size - 2, size - 2, 3, fillColor.getRGB());

        if (enabled) {
            int checkX = x + 2;
            int checkY = y + 6;

            for (int i = 0; i < 3; i++) {
                context.fill(checkX + i, checkY + i, checkX + i + 1, checkY + i + 1, Color.WHITE.getRGB());
            }

            for (int i = 0; i < 5; i++) {
                context.fill(checkX + 2 + i, checkY + 2 - i, checkX + 3 + i, checkY + 3 - i, Color.WHITE.getRGB());
            }
        }
    }

    public static Color getCategoryColor(com.volt.module.Category category) {
        return switch (category) {
            case COMBAT -> new Color(236, 110, 170);
            case MOVEMENT -> new Color(110, 190, 255);
            case PLAYER -> new Color(150, 110, 255);
            case RENDER -> new Color(190, 140, 255);
            case MISC -> new Color(130, 130, 255);
            case CLIENT -> new Color(170, 165, 215);
            case CONFIG -> new Color(100, 170, 255);
        };
    }
}
